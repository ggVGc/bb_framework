
dofile("bounce/main.lua")


Main = {}

function Main.new()
  M = {}

  function M.doFrame(deltaMs)
    update(deltaMs)
    draw()
  end

  init()
  return M
end





--
--
--dofile("class.lua")
--dofile("character.lua")
--dofile("map.lua")
--dofile("oceanmap.lua")
--dofile("camera.lua")
--dofile("fps_counter.lua")
--dofile("gamestate.lua")

--camera = nil
--fpsCounter = nil

--function init()
  --trace("WinWidth:"..screenWidth().."  WinHeight: "..screenHeight());
  --camera = Camera:new()

  --changeGameState("menu_state")
  --fpsCounter = FpsCounter:new()
--end

--function update(deltaMs)
  
  --fpsCounter:update(deltaMs)
  --if fpsCounter:hasNew() then
    ----trace("FPS: "..fpsCounter:current())
  --end

  --updateGameState(deltaMs)
  --camera:update(deltaMs)
--end

--function draw()
  --drawGameState()
--end



--function init()
  --b = bitmapCreate("f.png")
  --bg = bitmapCreate("reef.png")
  --camPos = 0
--end

--function update(d)
  ----trace("Delta: "..d)
  --if d > 1000 or d<0 then
    --return
  --end
  --camPos = camPos + 0.1*d
  --setCameraY(camPos)
  ----trace(camPos)
--end

--function draw()
  --bitmapDraw(bg, 0, 0)
  --for i = 0,10 do
    --bitmapDraw(b, 0, i*100)
    --bitmapDraw(b, 0, 100)
  --end
--end
