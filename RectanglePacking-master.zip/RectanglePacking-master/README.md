Rectangle Packer
================

ActionScript3 utility class to pack smaller rectangles within larger container rectangle efficiently.

Packs 500 rectangles in 1-2ms on a decent computer.

For more information visit [Rectangle Packing](http://villekoskela.org/2012/08/12/rectangle-packing/)

Sends your questions and feedback to ville@villekoskela.org

